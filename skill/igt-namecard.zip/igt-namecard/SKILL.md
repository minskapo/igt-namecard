---
name: "igt-namecard"
description: "녹색전환연구소 구성원 명함을 새로 발급·재발급하거나 명함생성기 웹페이지(minskapo.github.io/igt-namecard)를 고칠 때 사용. 인쇄용 AI·QR 추적링크·시트 기록·강프린팅 발주까지 처리."
---

# 녹색전환연구소 명함 발급·명함생성기 관리

명함은 명함생성기 웹페이지에서 만든다. 이 스킬은 (A) 신규·재발급 명함을 처리하는 업무 흐름과 (B) 웹페이지를 고칠 때 지켜야 할 규칙을 담는다. 일반 구성원은 A만 쓰면 되고, B는 웹페이지 관리자용이다.

## 기본 정보

- 명함생성기: https://minskapo.github.io/igt-namecard/ (GitHub `minskapo/igt-namecard`, GitHub Pages 배포)
- 배포: `main` 브랜치에 push하면 GitHub Pages가 자동 빌드한다(약 1~2분). 저장소 쓰기 권한은 관리자(기후시민팀 김민석)에게 요청한다.
- 구성원 원본: 구글 시트 '운영_구성원 DB (명함·메일서명)' `1qAy53XI3rvwB5zf1y3fYk7dm7XejXDxdo68vZmTd1MI`, 탭 '구성원'(헤더 `이메일 아이디/이름/영문 이름/부서/직급/국문 직함/영문 직함/핸드폰/이메일/상태/서명 언어/서명 코드/비고`). 명함생성기·메일 서명 도구가 함께 쓴다. 웹페이지에는 .xlsx로 받아 끌어다 놓는다(Google 로그인 불러오기는 OAuth 클라이언트 ID 설정 뒤 사용). 예전 `운영_연구소 구성원 연락처인쇄용_*.xlsx`도 읽힌다.
- 추적링크 시트: 녹색전환연구소 GA4 추적링크 생성기 `1C5ncxBevH9FuNXDelcyYIBg-rYFwMoAu8GtsUAkG-Jo`, 탭 'UTM코드 생성기'(gid 870958988), 소스 목록은 '설정' 탭 A열
- 인쇄소: 강프린팅 강원경 실장님 010-8863-7226, http://www.kangprinting.com/
- 인쇄 사양: 엑스트라매트 · 양면칼라 · 90×50mm
- 발주 시 반드시 전달: "사이즈는 90×50mm, 작업파일은 94×54mm(도련 2mm 적용)"
- 원본 디자인 템플릿: `녹색전환연구소 명함_별색_9050.ai` (앞면 PANTONE 909 C 별색, 뒷면 K100, 서체 Asta Sans SemiBold)

## A. 명함 발급 흐름

1. **정보 확인**: 이름, 부서, 직급, 휴대전화, 이메일(@igt.or.kr)을 받는다. 구성원 DB에 있으면 그대로 쓰고, 없으면 DB 시트에 먼저 한 줄을 추가한다.
2. **명함 내용 규칙** (웹페이지가 자동 적용, 사람이 볼 때 확인할 것)
   - 영문 이름: 국어의 로마자 표기법 + 관용 성씨(김 Kim, 이 Lee, 박 Park, 최 Choi, 정 Jeong, 윤 Yoon, 조 Cho, 장 Jang, 강 Kang, 오 Oh, 황 Hwang, 배 Bae, 고 Ko, 여 Yeo…), 'Given Family' 순. 본인이 쓰는 표기가 따로 있으면 그것을 우선한다.
   - 국문 직함 줄: `부서 직급` (이사장·소장·부소장은 직급만)
   - 영문 직함 줄: `직급영문, 팀영문`. 팀: 경제전환팀 Economic Transformation Team / 지역전환팀 Local Transformation Team / 기후시민팀 Climate Advocacy Team / 운영기획팀 Operations & Strategy Team. 직급: 이사장 Chairperson, 소장 Director, 부소장 Deputy Director, 팀장 Team Leader, 선임연구원 Senior Researcher, 연구원 Researcher, 인턴연구원 Research Intern. 폭(150pt)을 넘으면 쉼표 뒤에서 2줄로 나뉜다.
   - 전화 표기: `010  1234  5678` (숫자 묶음 사이 공백 2칸), 사무실 `02  2135  1148`
   - 주소: `서울 중구 중림로7길 4, 2층 녹색전환연구소`
3. **QR 추적링크**: 랜딩 `https://igt.or.kr/`, `utm_source=bizcard`, `utm_medium=qrcode`, `utm_campaign=business_card`, `utm_content=<이메일 아이디>`. 순서는 시트 K열 수식과 같게 source→medium→campaign→content. QR에는 da.gd 단축링크(코드 = `igt` + UTM 링크의 FNV-1a 해시 base36 7자, 이미 있으면 재사용)가 들어간다. 웹페이지가 이메일 입력 시 자동 생성한다.
4. **파일 만들기**: 웹페이지에서 엑셀을 불러오거나 '신규 입사자 직접 입력'으로 입력 → 미리보기 확인 → '인쇄발주용 AI'(여러 명이면 사람별 파일 ZIP), 필요하면 'PNG 이미지'(재단 90×50mm, 600dpi). 내용 수정은 엑셀이나 웹페이지 ③에서 하고 다시 받는다. 글자 편집용 AI는 제공하지 않는다.
5. **시트 기록**: 'UTM코드 생성기' 탭 맨 아래 빈 행에 A~L열을 채운다. Google Sheets 커넥터가 있으면 직접 쓰고(USER_ENTERED), 없으면 웹페이지 '시트에 붙여넣을 행 복사'를 안내한다.
   - A 생성일(YYYY-MM-DD) · B `명함생성기 자동생성` · C `명함 QR코드 - 이름 (국문 직함)` · D `https://igt.or.kr/` · E `business_card` · F `bizcard` · G `qrcode` · H 이메일 아이디 · I·J 빈칸 · K 기존 행과 같은 수식(행 번호만 바꿈) · L 단축링크
   - 같은 사람이 이미 기록되어 있으면 새로 쓰지 않는다.
6. **인쇄 발주**: 강원경 실장님께 보낼 메시지를 초안으로 만든다(사양, 인원·이름, 수량, 파일). 메시지에는 "사이즈는 90×50mm, 작업파일은 94×54mm(도련 2mm 적용)"이라는 문장을 반드시 넣는다. 메시지·메일 발송은 사용자 확인 후에만 한다.

## B. 웹페이지를 고칠 때

### 파일 구조

- `js/card-data.js`: 엑셀 파싱, 로마자, `TEAM_EN`·`TITLE_EN`, 주소·사무실 전화(`OFFICE`)
- `js/card-link.js`: UTM 규칙(`LINK`), da.gd 단축링크, 시트 행(`sheetRow`, 작성자 상수 `AUTHOR`)
- `js/card-pdf.js`: 레이아웃 좌표(pt, 페이지 94×54 원점 기준), 글자 외곽선, QR(버전 3·ECC M부터, 약 8mm), 투명 박스, 페이지 상자
- `js/card-ai.js` + `js/card-ai-data.js`: Illustrator 편집 데이터(AI private data) 생성, 앞·뒷면 고정 아트 조각
- `assets/base.pdf`: 원본 템플릿에서 Illustrator 데이터·가변 텍스트·QR·재단선 테두리를 걷어낸 바탕
- `vendor/`: pdf-lib, fontkit, SheetJS, pdf.js, qrcode-generator, JSZip (자체 호스팅)

### 반드시 지킬 것 (Illustrator 호환, 검수에서 확인된 사항)

- 대지 = 재단 90×50mm, 문서 도련 2mm(편집 데이터에 `BleedLeft/Top/Right/BottomValue` 5.6693), 단위 mm(`%AI5_RulerUnits: 1`). PDF 페이지는 94×54mm, 원점 (0,0), TrimBox 2mm 안쪽.
- 투명 박스 2개: 94×54mm(도련선), 90×50mm(재단선). 편집 데이터에서는 칠·선 없는 패스(`n`).
- 편집 데이터 컨테이너는 `%AI24_ZStandard_Data` + zstd 프레임(무압축 Raw 블록 허용), 64KB씩 `AIPrivateData1..N`, `/ContainerVersion 12 /CreatorVersion 30 /RoundtripStreamType 2 /RoundtripVersion 24`.
- 페이지의 `/PieceInfo << /Illustrator N 0 R >>`는 반드시 **간접 객체**. 직접 사전으로 넣으면 더블클릭 시 'PDF 가져오기'로 열리고 '무제' 문서가 된다.
- 글자 외곽선 컴파운드 패스는 윤곽선마다 시작점을 끝에 다시 찍어 닫는다. 안 그러면 Illustrator에서 L·E·김 등이 깨진다.
- 아트보드마다 레이어 1개(`01_이름_앞면`) + 그룹 1개. 일반 PDF 그룹(폼 XObject 등)은 VectorCraft·Illustrator가 풀어 버리므로 그룹은 편집 데이터로만 유지된다.
- 첫 번째 대지를 활성대지로 지정한다(편집 데이터의 `ArtboardArray` 뒤에 `0 /Int (CropAreaActive)`). 빠지면 디자이너가 활성대지를 다시 지정해야 한다.
- 대지별 `RulerOrigin`은 반올림하지 않고 정확한 값을 넣어 눈금자 0점이 대지 왼쪽 위에 오게 한다.
- 글자 편집용(서체 텍스트) AI는 편집 데이터에 텍스트를 담을 수 없어 만들지 않는다.

### 수정·배포 절차

1. 저장소(`minskapo/igt-namecard`)를 내려받아 수정한다.
2. `index.html`의 스크립트·CSS `?v=` 버전 태그와 `app.js`의 `base.pdf?v=`를 올린다(브라우저 캐시 무효화).
3. Playwright로 엑셀 불러오기 → 1명·여러 명 AI/PNG 내려받기를 시험한다(da.gd는 라우트 가로채기로 대체 가능).
4. 검증: PDF 렌더(PyMuPDF)로 텍스트·QR 디코딩(cv2) 확인. Illustrator가 있으면 `open -a "Adobe Illustrator" 파일.ai` 후 창 목록에 'PDF 가져오기 옵션'이 없는지, ExtendScript로 `artboards`·`layers`·`rulerUnits`를 확인한다. 모달이 뜨면 CGEvent로 Esc. VectorCraft CLI(`vectorcraft-cli info/convert`)로도 레이어·그룹을 확인할 수 있다.
5. 커밋·`git push` 후 `gh api repos/minskapo/igt-namecard/pages/builds/latest`로 빌드 완료를 확인한다.

### 개인정보

- 저장소·웹페이지에는 구성원 명단을 두지 않는다. 엑셀은 브라우저 안에서만 읽힌다.
- 추적링크 시트는 연구소 계정 안에서만 공유한다.