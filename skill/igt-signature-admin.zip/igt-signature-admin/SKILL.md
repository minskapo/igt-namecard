---
name: "igt-signature-admin"
description: "녹색전환연구소 메일 서명 관리자·운영 담당자용. 신규 구성원 서명 발급, GAM 일괄 적용, 서명 이미지 저장소 업로드, 추적링크 시트 기록, 셀프 반영 웹앱 관리, 메일 서명 도구 수정 때 사용."
---

# 녹색전환연구소 메일 서명: 관리자용

이 스킬은 Google Workspace 관리자와 운영 담당자용이다. 구성원 개인 설정(‘--’ 줄, 영문 서명, 직함 바꾸기)은 구성원용 스킬 `igt-email-signature`와 서명 페이지가 맡는다.

메일 서명은 '디자인 산출물 통합도구'의 메일 서명 도구에서 만든다. 이 스킬은 (A) 신규·변경 서명을 처리하는 업무 흐름, (B) 적용·문제 해결, (C) 도구를 고칠 때 지켜야 할 규칙을 담는다.

## 기본 정보

- 메일 서명 도구: https://minskapo.github.io/igt-namecard/signature.html (명함생성기와 같은 저장소 `minskapo/igt-namecard`, GitHub Pages)
- 구성원 DB: 구글 시트 '운영_구성원 DB (명함·메일서명)' `1qAy53XI3rvwB5zf1y3fYk7dm7XejXDxdo68vZmTd1MI`, 탭 '구성원'
  - 열: 이메일 아이디 · 이름 · 영문 이름 · 부서 · 직급 · 국문 직함 · 영문 직함 · 핸드폰 · 이메일 · 상태(재직/퇴사) · 서명 언어(국문/영문) · 서명 코드 · 비고
  - 서명 코드: 서명 이미지 주소에 쓰는 무작위 12자. 한 번 정하면 바꾸지 않는다(바꾸면 이미 적용된 서명의 이미지가 끊긴다).
- 추적링크 시트: GA4 추적링크 생성기 `1C5ncxBevH9FuNXDelcyYIBg-rYFwMoAu8GtsUAkG-Jo`, 탭 'UTM코드 생성기'(gid 870958988)
- 일괄 적용: Google Workspace 관리자가 GAM으로 적용한다. 관리자 안내 페이지: https://minskapo.github.io/igt-namecard/admin.html
- 셀프 반영 웹앱: `tools/sig-self.gs`(Apps Script). 구성원이 서명 페이지에서 본인 정보를 불러오고(me), 바꾼 직함의 서명 이미지를 본인 서명 코드 폴더에 올리며 DB 직함 칸을 고친다(publish). GitHub 토큰은 스크립트 속성 `GITHUB_TOKEN`에만 둔다. 웹앱 URL은 `js/db-load.js`의 `selfUrl`.

## 서명 디자인 (확정)

- F안, 폭 600px(테두리 포함 602px), 흰 카드 + 위쪽 연두 그라디언트 띠(이름·직함·둘째 줄) + 연락처 줄(M·T·E 한 줄) + 주소 + 구분선 + 비전 문구 + 버튼 + 로고.
- 서체 Asta Sans. 이름 21px 굵게, 직함 15px, 둘째 줄 13px, 연락처 14.5px, 주소·비전 13px, 버튼 14px.
- 국문: 이름 / 국문 직함 / `영문 이름 | 영문 직함 줄`, 버튼 후원하기(검정)·뉴스레터·홈페이지, 로고 '국문 시그니처'. 비전 "지구의 수용 한계 안에서 누구나 기초적인 삶을 누릴 수 있는 사회를 만듭니다."
- 영문: 영문 이름 / 직급 / `팀 | Institute for Green Transformation`, 버튼 LinkedIn(검정, 왼쪽)·Website, 로고 igt 영문 혼합형. 비전 "A good life for all, within a living planet". 전화는 +82 형식.
- 서명 전체가 이미지다(다크모드에서도 색 유지). 글자가 서명 폭을 넘으면 도구가 글자를 조금씩 줄이고 경고한다.
- 이미지 조각
  - 사람별: `assets/email/sig/<서명 코드>/<kr|en>_a.png`(이름 영역), `_m1·_m2·_m3`(휴대전화·사무실·메일 칸), `_b`(주소·비전). 2배율.
  - 공통: `assets/email/sig/common/<kr|en>/row0~N.png`(버튼 줄, 버튼 하나당 한 칸. 칸 경계는 버튼 사이 간격의 가운데), `bot.png`, `tpl.png`(글자 없는 윗부분 바탕), `layout.json`(배치 값). 3배율.
  - 연락처 칸에는 `tel:+82…`, `mailto:` 링크, 버튼 칸에는 UTM 링크, 나머지는 홈페이지(`utm_term=card`).

## 링크·UTM 규칙

- 공통: `utm_source=signature` · `utm_medium=email` · `utm_campaign=email_signature` · `utm_content=<이메일 아이디>` · `utm_term=<누른 곳>`
- 순서는 추적링크 시트 K열 수식과 같게 source→medium→campaign→content→term.
- utm_term: `donate`(후원하기), `newsletter`(뉴스레터), `homepage`(홈페이지), `website`(영문 Website), `card`(버튼 밖 영역). LinkedIn은 UTM 없이 `https://www.linkedin.com/company/institute-for-green-transformation/home/ (연구소 공식 페이지)`.
- 랜딩: 후원 `https://igt.or.kr/project2030/`(주소를 바꿀 때는 `js/sig-core.js`의 `LINK.donate`와 추적링크 시트 donate 행을 함께 바꾼다), 뉴스레터 `https://igtkorea.stibee.com/`, 홈페이지 `https://igt.or.kr/`.
- GA4: 세션 소스/매체 `signature / email`, 콘텐츠(사람)·검색어(버튼)로 나눠 본다.

## A. 신규 구성원·정보 변경

1. **DB에 적기**: '구성원' 탭에 한 줄 추가(이메일 아이디·이름·부서·직급·핸드폰·이메일). 영문 이름·직함은 비우면 자동 생성되지만, 영문 이름은 본인 표기를 확인한다. 퇴사자는 상태를 '퇴사'로 바꾼다.
2. **배포 파일 받기**: 도구에서 DB(.xlsx)를 불러와 그 사람을 고르고 '배포 파일 ZIP'을 받는다. 서명 코드가 없던 사람은 새 코드가 만들어지며 `서명코드_DB기록.csv`에 적힌다 → DB '서명 코드' 칸에 옮겨 적는다(Google Sheets 커넥터가 있으면 직접 쓴다).
3. **이미지 올리기**: ZIP의 `저장소에_올릴_파일/assets`를 저장소 맨 위에 덮어쓰고 커밋·push. 1~2분 뒤 `이미지_주소_확인.txt`의 주소가 열리는지 확인한다.
4. **추적링크 기록**: 사람당 5줄(donate·newsletter·homepage·website·card). 도구의 '추적링크 시트 행 복사' 또는 ZIP의 `추적링크_시트행.tsv`를 'UTM코드 생성기' 탭 맨 아래 빈 행 A열에 붙인다. 커넥터로 직접 쓸 때는 A~J열 값을 쓰고 K열은 같은 탭의 기존 수식(utm_term까지 들어 있는 행, 예: 40행)을 복사한다. 이미 기록된 사람은 다시 쓰지 않는다.
5. **적용**: 관리자가 `gam user <이메일> signature file gam/html/<아이디>.html html`. 관리자가 없으면 본인이 개별 설치한다.

## B. 적용·문제 해결

- 일괄 적용(ZIP 폴더에서): `gam csv gam/signatures.csv gam user ~email signature file ~file html`, 확인 `gam user <이메일> show signature`. 사람마다 DB '서명 언어' 하나만 들어간다. 영문을 함께 쓰려면 개별 설치로 추가.
- GAM 첫 설정: 설치 → `gam create project` → `gam oauth create`(기본 선택 그대로 `c`) → `gam user <관리자> check serviceaccount`. 안내 링크로 도메인 전체 위임을 승인하되, 범위는 서명에 필요한 `https://www.googleapis.com/auth/gmail.settings.basic` 하나만 남기는 것을 권한다(다른 범위는 FAIL로 남아도 된다).
- 맥 zsh에서는 `~email`, `~file`을 작은따옴표로 감싼다: `gam csv gam/signatures.csv gam user '~email' signature file '~file' html`.
- 구성원 개인 설정과 개별 설치 안내는 서명 페이지(`#bilingual`, `#self`, `#personal`)로 안내한다.
- 셀프 반영이 실패하면: 웹앱 URL·`GITHUB_TOKEN` 만료(1년)·DB에 서명 코드가 있는지 확인한다. 셀프 반영은 DB의 국문·영문 직함만 고친다. 이름·전화·부서는 관리자가 DB를 고치고 다시 적용한다.
- 이미지가 X로 보임: 저장소에 아직 안 올라갔거나 push 직후. 도구 미리보기 아래 '이미지 준비됨' 여부를 본다.
- 바뀐 내용이 안 보임: 이미지를 올린 뒤 서명을 다시 적용해야 한다(주소의 `?v=` 값이 바뀐다).
- 링크가 google.com/url을 거침: 받는 쪽 Gmail의 안전 확인 기능이라 끌 수 없다. Claude의 Gmail 커넥터로 보낸 테스트 메일도 링크가 감싸진다(실제 서명과 다름).
- 테스트 메일을 Gmail 커넥터로 보낼 때: 외부 이미지는 지워지므로 이미지를 `inline` 첨부(`cid:attN`)로 넣는다. 한 통에 첨부 10개까지만 된다. 발송 전 사용자 확인을 받는다.

## C. 도구를 고칠 때

- 파일: `signature.html`(구성원용), `admin.html`(관리자 안내), `tools/sig-self.gs`(셀프 반영 웹앱), `css/sig.css`, `js/sig-core.js`(글자 구성·링크·UTM·HTML·시트 행), `js/sig-render.js`(캔버스로 사람별 이미지 그리기·조각 자르기), `js/sig-app.js`(화면·복사·ZIP), `js/sig-glyphs.js`(서체에 있는 한글 목록), `js/db-load.js`(Google 로그인 DB 불러오기, `clientId` 비면 비활성), `js/card-data.js`(DB 파싱, 명함과 공용).
- 공통 조각과 `layout.json`은 Playwright로 만든다(같은 CSS로 렌더 → 글자를 투명하게 한 바탕을 `tpl.png`로 저장, 버튼 위치로 조각을 자르고 기준선 b1·b2·b3, 연락처 줄 r3, 버튼 칸 너비를 기록). 디자인이나 폭을 바꾸면 공통 조각을 다시 만들고 `COMMON_VER`를 올린 뒤, 23명 이미지를 모두 다시 만들어 올린다.
- 폭이 아주 좁은 조각 이미지(수십 px 이하)를 만들지 않는다. Gmail 안드로이드 앱이 추적 픽셀로 보고 숨겨 다크모드에서 검은 칸이 생긴다.
- 화면 스크립트·CSS를 바꾸면 HTML의 `?v=` 버전 태그를 올린다.
- 저장소·웹페이지에 구성원 명단 파일을 두지 않는다. 서명 이미지는 공개 저장소에 올라가므로(이름·전화 포함) 이 점을 구성원에게 알린다.
- 커밋 후 push, `gh api repos/minskapo/igt-namecard/pages/builds/latest`로 빌드를 확인한다.
